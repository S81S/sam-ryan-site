SAM + RYAN VERIFIED WEBSITE V13
===============================

Purpose
- Independent personal-brand / car-shopping prototype for Samuel “Sam” Sweitzer and Ryan Sugrue.
- Current affiliation: Covert Chrysler Dodge Jeep Ram of Austin, 8107 Research Blvd, Austin TX 78758.
- Not the official dealership website.

Identity lock
- Only real staff photos supplied for Sam and Ryan are used as Sam/Ryan.
- No alternate dealership and no generated stand-ins.
- The See Yourself mockup places Ryan’s actual staff photo behind a CSS-drawn steering wheel; it is explicitly labeled a concept.

Inventory
- Current aggregate counts were checked from Covert’s official public search pages on Sept. 18, 2026.
- Find My Car and Compare use an 8-vehicle public-listing snapshot saved Sept. 12, 2026.
- Prices and availability must be reverified. Production launch requires automatic refresh.

Pages
- index.html: home
- inventory.html: current counts + saved VIN dataset
- find-my-car.html: natural-language prototype
- compare.html: VIN/stock comparison prototype
- see-yourself.html: consent-based visualization concept
- car-watch.html: local browser demo
- reviews.html: collected Sam + Ryan reputation evidence
- sam.html / ryan.html: individual profile pages
- guides.html: buying guides + content engine
- contact.html: prototype lead routing
- sources.html: verification ledger

Next production tasks
1. Domain + hosting.
2. Automatic inventory collector keyed by VIN.
3. Window sticker / equipment normalization.
4. Joint lead backend + Ryan contact preference.
5. Analytics/Search Console/Bing Webmaster.
6. High-resolution real photos of Sam and Ryan together and individually.
7. Publish real buying guides and videos.
