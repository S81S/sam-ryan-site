// ---------- live inventory loading --------------------------------------
// Set this to your deployed Worker's URL (see worker/README.md).
const INVENTORY_API_URL = 'https://samryan-inventory.YOUR-SUBDOMAIN.workers.dev/api/inventory';

// Small embedded fallback so the site still works if the API is down or
// not deployed yet. Same shape as before.
const FALLBACK_INVENTORY=[
{id:'r12377',year:2026,name:'Ram 1500 Big Horn / Lone Star',price:48525,miles:7,type:'Truck',newUsed:'New',drivetrain:'4WD',stock:'R12377',vin:'1C6SRFFT3TN400152',engine:'5.7L HEMI V8 eTorque',features:['4WD','heated seats','blind spot','tow package','parking assist','navigation','Apple CarPlay'],scoreBoost:['truck','tow','4wd','ram','v8'],sourceUrl:'https://www.covertchryslerdodgejeepram.com/auto/new-2026-ram-1500-lone-star-crew-cab-4x4-57-box-austin-tx/121531331/'},
{id:'r12558',year:2026,name:'Ram 1500 Laramie',price:57511,miles:7,type:'Truck',newUsed:'New',drivetrain:'4WD',stock:'R12558',vin:'3C6SRFJP3T4216155',engine:'3.0L I6',features:['4WD','heated seats','ventilated seats','blind spot','panoramic sunroof','premium sound','navigation','parking assist'],scoreBoost:['truck','cooled seats','premium','4wd','ram'],sourceUrl:'https://www.covertchryslerdodgejeepram.com/auto/new-2026-ram-1500-laramie-crew-cab-4x4-57-box-austin-tx/123215450/'},
{id:'j22079',year:2026,name:'Jeep Wrangler 2-Door Sport',price:35051,miles:7,type:'SUV',newUsed:'New',drivetrain:'4WD',stock:'J22079',vin:'1C4PJXAN4TW207376',engine:'2.0L I4 DOHC',features:['4WD','adaptive cruise','reverse camera','Apple CarPlay','Android Auto','12.3-inch touchscreen','fog lights'],scoreBoost:['off road','jeep','4wd','wrangler','adventure'],sourceUrl:'https://www.covertchryslerdodgejeepram.com/search/new-jeep-wrangler-austin-tx/?cy=78758&md=166&tp=new'},
{id:'d06075',year:2026,name:'Dodge Durango GT',price:38664,miles:7,type:'SUV',newUsed:'New',drivetrain:'RWD',stock:'D06075',vin:'1C4RDHDGXTC232318',engine:'3.6L V6',features:['3 rows','7 seats','heated seats','tow package','power lift gate','navigation','parking assist','premium sound'],scoreBoost:['family','three row','3 row','sporty','durango','7 seats'],sourceUrl:'https://www.covertchryslerdodgejeepram.com/auto/new-2026-dodge-austin-tx/118248041/'},
{id:'c288795a',year:2018,name:'Dodge Charger R/T',price:15447,miles:144556,type:'Car',newUsed:'Used',drivetrain:'RWD',stock:'C288795A',vin:'2C3CDXCT5JH113301',engine:'5.7L HEMI V8',features:['ventilated seats','heated seats','navigation','parking assist','premium sound','Apple CarPlay','Android Auto'],scoreBoost:['sporty','performance','charger','v8','used','car'],sourceUrl:'https://www.covertchryslerdodgejeepram.com/auto/used-2018-dodge-charger-rt-austin-tx/125251254/'},
{id:'c260872a',year:2024,name:'Ram 1500 Limited',price:44938,miles:70298,type:'Truck',newUsed:'Used',drivetrain:'4WD',stock:'C260872A',vin:'1C6SRFHT4RN121881',engine:'5.7L HEMI V8 eTorque',features:['4WD','heated seats','ventilated seats','360 camera','blind spot','panoramic sunroof','premium sound','navigation'],scoreBoost:['used','truck','ram','cooled seats','premium','4wd','360 camera'],sourceUrl:'https://www.covertchryslerdodgejeepram.com/auto/used-2024-ram-1500-limited-austin-tx/123199328/'},
{id:'c234923b',year:2017,name:'Chrysler Pacifica Limited',price:14447,miles:98572,type:'Minivan',newUsed:'Used',drivetrain:'FWD',stock:'C234923B',vin:'2C4RC1GG1HR770121',engine:'V6',features:['3 rows','heated seats','power lift gate','navigation','parking assist','premium sound','sunroof'],scoreBoost:['family','three row','3 row','minivan','used','pacifica'],sourceUrl:'https://www.covertchryslerdodgejeepram.com/auto/used-2017-chrysler-pacifica-limited-austin-tx/125224080/'},
{id:'r12598',year:2027,name:'Ram 1500 Rebel',price:68170,miles:7,type:'Truck',newUsed:'New',drivetrain:'4WD',stock:'R12598',vin:'1C6SRFLT6VN559321',engine:'5.7L HEMI V8',features:['4WD','heated seats','tow package','navigation','parking assist','premium sound','Apple CarPlay','Android Auto'],scoreBoost:['truck','ram','rebel','off road','4wd','v8'],sourceUrl:'https://www.covertchryslerdodgejeepram.com/auto/new-2027-ram-1500-rebel-crew-cab-4x4-57-box-austin-tx/124310004/'}
];

// Guesses a body-style bucket from the listing title. The worker's parser
// doesn't yet extract this directly from Covert's data — this is a rough
// stand-in until a later pass adds real body-style parsing.
function guessType(title){
  const t=(title||'').toLowerCase();
  if(/1500|2500|3500|ram\b/.test(t))return'Truck';
  if(/pacifica|voyager|promaster (cargo|passenger)/.test(t))return'Minivan';
  if(/wrangler|grand cherokee|compass|cherokee|gladiator|wagoneer|durango/.test(t))return'SUV';
  return'Car';
}

// Maps a raw API row (worker/schema.sql shape) onto the field names the
// rest of this file already expects (same shape the old hardcoded array
// used), so nothing else below has to change.
function normalizeApiVehicle(row){
  const type=guessType(row.title);
  // Verified equipment comes from the official window sticker (Monroney
  // label) the worker fetches per VIN — standard equipment plus the name
  // of any optional package/feature. This is real factory data, not a
  // guess, which is why it's kept separate from scoreBoost below.
  const standard=Array.isArray(row.standard_equipment)?row.standard_equipment:[];
  const optionalNames=Array.isArray(row.optional_equipment)?row.optional_equipment.map(o=>o.name).filter(Boolean):[];
  const features=[...standard,...optionalNames];
  return {
    id:row.stock_number,
    year:row.year,
    name:row.title||`${row.year||''} ${row.condition||''} vehicle`.trim(),
    price:row.price,
    miles:row.mileage||0,
    type,
    newUsed:row.condition,
    drivetrain:row.drivetrain||'',
    stock:row.stock_number,
    vin:row.vin,
    engine:row.engine||'',
    features,
    scoreBoost:[type.toLowerCase(),(row.condition||'').toLowerCase(),(row.drivetrain||'').toLowerCase()].filter(Boolean),
    sourceUrl:row.listing_url,
    // Window sticker fields: stickerStatus is 'ok' | 'not_found' | 'error'
    // | undefined (not fetched yet) — UI should only show the link when
    // it's actually 'ok', so we never link to a broken/missing PDF.
    stickerUrl:row.sticker_status==='ok'?row.sticker_url:null,
    stickerStatus:row.sticker_status||null,
    fuelEconomy:row.fuel_economy||null,
  };
}

async function loadInventory(){
  try{
    const res=await fetch(INVENTORY_API_URL,{headers:{Accept:'application/json'}});
    if(!res.ok)throw new Error('bad response '+res.status);
    const rows=await res.json();
    if(!Array.isArray(rows)||rows.length===0)throw new Error('empty inventory');
    return rows.map(normalizeApiVehicle);
  }catch(err){
    console.warn('Live inventory unavailable, using fallback snapshot:',err);
    return FALLBACK_INVENTORY;
  }
}

// ---------- everything below runs once inventory is resolved -------------
(async function init(){
const inventory=await loadInventory();
const SNAPSHOT_DATE='September 12, 2026';
const money=n=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:0}).format(n);
const safe=s=>(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const norm=s=>(s||'').toLowerCase().replace(/cooled seats/g,'ventilated seats').replace(/surround[- ]view/g,'360 camera').replace(/four[- ]wheel drive/g,'4wd').replace(/three[- ]row/g,'3 rows');
const carEmoji=t=>t==='Truck'?'🛻':t==='Car'?'🚘':t==='Minivan'?'🚐':'🚙';
function parseMoney(q){const m=q.match(/(?:under|max(?:imum)?|budget(?: of)?|up to|around)\s*\$?([0-9]{2,6})(?:,?000|k)?/i);if(!m)return null;let v=parseInt(m[1],10);return v<1000?v*1000:v}
function parseMiles(q){const m=q.match(/(?:under|max(?:imum)?|less than|below)\s*([0-9]{1,3})(?:,?000|k)?\s*(?:miles|mi)/i);if(!m)return null;let v=parseInt(m[1],10);return v<1000?v*1000:v}

document.querySelectorAll('[data-example]').forEach(b=>b.addEventListener('click',()=>{const el=document.getElementById('request');if(el){el.value=b.dataset.example;el.focus()}}));

const matchBtn=document.getElementById('matchBtn');
matchBtn?.addEventListener('click',()=>{
 const raw=document.getElementById('request')?.value.trim()||'';const q=norm(raw);const budget=parseMoney(q),maxMiles=parseMiles(q);
 const terms=['3 rows','4wd','rwd','ventilated seats','adaptive cruise','heated seats','360 camera','tow package','premium sound','navigation','truck','suv','car','minivan','used','new','sporty','performance'];
 const ranked=inventory.map(v=>{let score=48;const reasons=[],misses=[];const hay=norm([v.type,v.newUsed,v.drivetrain,...v.features,...v.scoreBoost].join(' '));terms.forEach(t=>{if(q.includes(t)){if(hay.includes(t)){score+=9;reasons.push(t)}else{score-=9;misses.push(t)}}});if(q.includes('family')&&(hay.includes('family')||hay.includes('3 rows'))){score+=12;reasons.push('family-friendly')}if((q.includes('off road')||q.includes('off-road'))&&hay.includes('off road')){score+=12;reasons.push('off-road focus')}if(q.includes('truck')&&v.type==='Truck'){score+=14;reasons.push('truck')}if(q.includes('suv')&&v.type==='SUV'){score+=14;reasons.push('SUV')}if(q.includes('used')&&v.newUsed==='Used'){score+=12;reasons.push('used')}if(q.includes('new')&&v.newUsed==='New'){score+=12;reasons.push('new')}if(q.includes('sporty')&&(hay.includes('sporty')||hay.includes('performance'))){score+=14;reasons.push('sporty/performance')}if(budget){if(v.price<=budget){score+=18;reasons.push('within budget')}else{score-=Math.min(36,Math.ceil((v.price-budget)/2500)*6);misses.push(`${money(v.price-budget)} over budget`)}}if(maxMiles&&v.newUsed==='Used'){if(v.miles<=maxMiles){score+=12;reasons.push('within mileage limit')}else{score-=25;misses.push('over mileage limit')}}score=Math.max(8,Math.min(99,score));return {...v,score,reasons:[...new Set(reasons)],misses:[...new Set(misses)]}}).sort((a,b)=>b.score-a.score).slice(0,4);
 const out=document.getElementById('matchResults');if(out)out.innerHTML=ranked.map(v=>`<div class="match"><div class="score">${v.score}% MATCH</div><div class="live-badge">${v.stickerUrl?'WINDOW-STICKER VERIFIED':'SEPT. 12 PUBLIC SNAPSHOT'}</div><h4>${v.year} ${safe(v.name)}</h4><p>${money(v.price)} • ${v.newUsed}${v.newUsed==='Used'?` • ${v.miles.toLocaleString()} miles`:''} • Stock ${safe(v.stock)}</p><p>${(v.reasons.length?v.reasons:v.features.slice(0,4)).map(x=>'✓ '+safe(x)).join(' &nbsp; ')}</p>${v.misses.length?`<p class="match-misses">Verify: ${v.misses.map(safe).join(' • ')}</p>`:''}<div class="match-actions"><a class="mini-btn" href="compare.html">Compare</a>${v.stickerUrl?`<a class="mini-btn alt" href="${v.stickerUrl}" target="_blank" rel="noopener">Window sticker ↗</a>`:''}<a class="mini-btn alt" href="${v.sourceUrl}" target="_blank" rel="noopener">Official listing ↗</a><a class="mini-btn" href="contact.html">Ask Sam + Ryan</a></div></div>`).join('')+`<div class="micro">Matching uses the saved public-listing snapshot checked ${SNAPSHOT_DATE}. Current price, incentives and availability must be re-verified on Covert’s official site.</div>`;
});

const invGrid=document.getElementById('inventoryGrid');let currentFilter='all';
function renderInventory(){if(!invGrid)return;const filtered=inventory.filter(v=>currentFilter==='all'||v.newUsed===currentFilter||v.type===currentFilter);invGrid.innerHTML=filtered.map(v=>`<article class="inventory-card"><div class="vehicle-art"><span class="vehicle-status">${v.newUsed}</span><span class="car-icon">${carEmoji(v.type)}</span><span class="verified-stock">Stock ${safe(v.stock)}</span></div><div class="inventory-card-copy"><span class="chip">${v.stickerUrl?'VERIFIED VIA WINDOW STICKER':'PUBLIC LISTING SNAPSHOT'}</span><h3>${v.year} ${safe(v.name)}</h3><div class="inventory-price">${money(v.price)}</div><div class="inventory-meta"><span>${safe(v.type)}</span><span>${safe(v.drivetrain)}</span>${v.newUsed==='Used'?`<span>${v.miles.toLocaleString()} miles</span>`:''}<span>${safe(v.engine)}</span>${v.features.slice(0,4).map(x=>`<span>${safe(x)}</span>`).join('')}</div><div class="vin-line">VIN ${safe(v.vin)}</div><div class="inventory-actions"><a class="mini-btn" href="compare.html">Compare</a>${v.stickerUrl?`<a class="mini-btn alt" href="${v.stickerUrl}" target="_blank" rel="noopener">Window sticker ↗</a>`:''}<a class="mini-btn alt" href="${v.sourceUrl}" target="_blank" rel="noopener">Official listing ↗</a><a class="mini-btn" href="contact.html">Ask us</a></div></div></article>`).join('')}
if(invGrid){renderInventory();document.querySelectorAll('[data-inventory-filter]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-inventory-filter]').forEach(x=>x.classList.remove('active'));b.classList.add('active');currentFilter=b.dataset.inventoryFilter;renderInventory()}))}

const aSel=document.getElementById('vehicleA'),bSel=document.getElementById('vehicleB'),compOut=document.getElementById('compareOutput');
function fillSelect(sel){if(!sel)return;inventory.forEach(v=>{const o=document.createElement('option');o.value=v.id;o.textContent=`${v.year} ${v.name} — ${money(v.price)}`;sel.appendChild(o)})}
function renderCompare(){if(!aSel||!bSel||!compOut)return;const a=inventory.find(v=>v.id===aSel.value),b=inventory.find(v=>v.id===bSel.value);if(!a||!b)return;
 const shared=a.features.filter(x=>b.features.includes(x)),aOnly=a.features.filter(x=>!b.features.includes(x)),bOnly=b.features.filter(x=>!a.features.includes(x));
 const bothVerified=a.stickerUrl&&b.stickerUrl;
 const verificationNote=bothVerified
  ?'Equipment below comes from each vehicle\u2019s official window sticker — this is factory-verified, not a guess.'
  :'One or both window stickers aren\u2019t available yet, so this equipment list may be incomplete — use the sticker link(s) below to check directly once available.';
 compOut.innerHTML=`<div class="comparison-summary"><div class="compare-vehicle"><span>VEHICLE A • ${safe(a.stock)}</span><h3>${a.year} ${safe(a.name)}</h3><p>${money(a.price)} • ${a.newUsed} • ${safe(a.drivetrain)}</p><small>VIN ${safe(a.vin)}</small>${a.stickerUrl?`<div><a class="mini-btn alt" href="${a.stickerUrl}" target="_blank" rel="noopener">Open window sticker ↗</a></div>`:''}</div><div class="compare-vehicle"><span>VEHICLE B • ${safe(b.stock)}</span><h3>${b.year} ${safe(b.name)}</h3><p>${money(b.price)} • ${b.newUsed} • ${safe(b.drivetrain)}</p><small>VIN ${safe(b.vin)}</small>${b.stickerUrl?`<div><a class="mini-btn alt" href="${b.stickerUrl}" target="_blank" rel="noopener">Open window sticker ↗</a></div>`:''}</div></div><div class="comparison-table"><div><span>Shared</span><b>${shared.join(' • ')||'No shared tracked features'}</b></div><div><span>A only</span><b>${aOnly.join(' • ')||'—'}</b></div><div><span>B only</span><b>${bOnly.join(' • ')||'—'}</b></div><div><span>Price gap</span><b>${money(Math.abs(a.price-b.price))}</b></div></div><div class="snapshot-note">${verificationNote}</div><div class="compare-source-row"><a class="mini-btn alt" href="${a.sourceUrl}" target="_blank" rel="noopener">Vehicle A official listing ↗</a><a class="mini-btn alt" href="${b.sourceUrl}" target="_blank" rel="noopener">Vehicle B official listing ↗</a><span>Saved snapshot checked ${SNAPSHOT_DATE}</span></div>`}
if(aSel&&bSel){fillSelect(aSel);fillSelect(bSel);if(inventory[0])aSel.value=inventory[0].id;if(inventory[1])bSel.value=inventory[1].id;aSel.addEventListener('change',renderCompare);bSel.addEventListener('change',renderCompare);renderCompare()}

document.querySelectorAll('[data-review-filter]').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('[data-review-filter]').forEach(x=>x.classList.remove('active'));btn.classList.add('active');const f=btn.dataset.reviewFilter;document.querySelectorAll('[data-person]').forEach(q=>q.classList.toggle('hidden',f!=='all'&&q.dataset.person!==f))}));

document.getElementById('watchForm')?.addEventListener('submit',e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.currentTarget));const saved=JSON.parse(localStorage.getItem('samRyanCarWatch')||'[]');saved.push({...d,createdAt:new Date().toISOString()});localStorage.setItem('samRyanCarWatch',JSON.stringify(saved));const msg=document.getElementById('watchMessage');if(msg)msg.textContent=`Saved locally for ${d.name}. This prototype does not send data to a server yet.`;e.currentTarget.reset()});

document.getElementById('contactForm')?.addEventListener('submit',e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.currentTarget));const subject=encodeURIComponent(`Sam + Ryan website inquiry — ${d.advisor}`);const body=encodeURIComponent(`Name: ${d.name}\nPreferred advisor: ${d.advisor}\nReply to: ${d.reply}\n\nShopping request:\n${d.message}\n\nSource: Sam + Ryan prototype`);const target='samuelsweitzer@covertauto.com';const msg=document.getElementById('contactMessage');if(msg)msg.innerHTML=`This prototype opens your email app. <a href="mailto:${target}?subject=${subject}&body=${body}">Open email manually</a>.`;window.location.href=`mailto:${target}?subject=${subject}&body=${body}`});

const advisorParam=new URLSearchParams(location.search).get('advisor');const advisorSelect=document.getElementById('contactAdvisor');if(advisorParam&&advisorSelect&&[...advisorSelect.options].some(o=>o.value===advisorParam))advisorSelect.value=advisorParam;

})();
