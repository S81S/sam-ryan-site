# Sam + Ryan inventory worker

A Cloudflare Worker that crawls Covert's public inventory pages on a
schedule, stores results in a D1 database, and serves them as JSON so
the main site can show real, refreshing inventory instead of the
hardcoded 8-vehicle snapshot.

## What this does NOT do yet

This was written and reviewed without live access to deploy or test
against the real site (I can build code, but I can't run it against
the internet from where I work). Treat the first deploy as a
**calibration pass**, not a finished product. Specifically:

- The pagination URL parameter (`pt=` in `pageUrlFor()`) is a guess
  based on common Dealer eProcess patterns — it needs to be confirmed
  against the real site's page-2 URL.
- The parsing in `parseVehicles()` uses flexible regex against stable
  label text ("Stock#:", "Covert Sale Price$...") rather than exact
  CSS selectors, but it still needs a first real run to confirm it's
  pulling clean data (right prices, right VINs, no garbage titles).

Budget 30–60 minutes for this calibration step after first deploy —
see "Calibrating" below.

## One-time setup

```bash
cd worker
npm install
npx wrangler login

# Create the database
npx wrangler d1 create samryan-inventory
# → copy the database_id it prints into wrangler.toml

# Apply the schema
npx wrangler d1 execute samryan-inventory --file=./schema.sql --remote

# Set the admin key (used to manually trigger a crawl for testing)
npx wrangler secret put ADMIN_KEY
# → paste any random string when prompted; keep it private

# Update wrangler.toml:
#  - database_id (from the create step above)
#  - ALLOWED_ORIGIN (your real site's domain once you're off *.pages.dev)

npx wrangler deploy
```

This gives you a URL like `https://samryan-inventory.<your-subdomain>.workers.dev`.

## Calibrating (do this once, right after first deploy)

1. **Confirm the pagination parameter.** In a browser, go to the live
   new-inventory search page and click to page 2. Look at the URL —
   whatever query parameter changed is what belongs in `pageUrlFor()`
   in `src/index.js`. Update it and redeploy if it's not `pt`.

2. **Run one crawl step manually:**
   ```bash
   curl -X POST "https://samryan-inventory.<your-subdomain>.workers.dev/api/crawl-now?source=new" \
     -H "x-admin-key: YOUR_ADMIN_KEY"
   ```
   This crawls 5 pages and returns a summary. Repeat a couple of times
   (it resumes where it left off) to get real data in.

3. **Check the results:**
   ```bash
   curl "https://samryan-inventory.<your-subdomain>.workers.dev/api/inventory?condition=New"
   ```
   Compare 2–3 entries against the live site: does the price match?
   Is the VIN valid (17 characters)? Does the title look like a real
   vehicle name and not a chunk of description text? If something's
   off, that tells you which regex in `parseVehicles()` needs
   loosening or tightening — the file has comments pointing at each
   field.

4. Once it looks right, leave it — the cron trigger takes over from
   there, re-crawling continuously in the background.

## API

- `GET /api/inventory` — all current (non-removed) vehicles as JSON.
- `GET /api/inventory?condition=New` or `?condition=Used` — filtered.
- `GET /api/inventory/meta` — crawl status: current page, last
  completed pass, counts by condition. Good for a debugging/status
  check.
- `POST /api/crawl-now?source=new|used` — manually trigger one crawl
  step. Requires header `x-admin-key: <your ADMIN_KEY>`.

## Connecting the main site

`app.js` on the main site should fetch from this Worker's
`/api/inventory` endpoint instead of using the hardcoded array. See
the updated `app.js` — it tries the live API first and falls back to
a small embedded sample if the fetch fails, so the site never breaks
if the Worker is down or still warming up.

Set the Worker's real URL as `INVENTORY_API_URL` near the top of
`app.js`.

## Window stickers (verified equipment)

Stellantis (Jeep/Ram/Dodge/Chrysler — everything Covert sells) publishes
the official Monroney label PDF directly, by VIN, for free:
`https://www.<brand-site>.com/hostd/windowsticker/getWindowStickerPdf.do?vin=<VIN>`.
The worker fetches these on a rolling basis (a handful of VINs per cron
tick, tracked with its own cursor so it doesn't redo the whole list every
run), extracts the standard/optional equipment and MSRP breakdown from
the PDF text, and stores it in the `window_stickers` table. `/api/inventory`
joins this in automatically — `app.js` uses it for Compare's shared/
only-on-A/only-on-B equipment and for the "Window sticker ↗" links.

**This needs the $5/mo Workers Paid plan.** PDF text extraction is much
heavier than the plain-text page scraping the inventory crawler does,
and the free plan's CPU-time limit per invocation is very tight — likely
too tight for this. If stickers are consistently coming back `status:
'error'` after deploy, this is the first thing to check (Cloudflare
dashboard → Workers → your account plan).

**Calibrating the sticker parser (do this after first deploy):**

1. Pick one VIN you know is real and recent (from `/api/inventory`).
2. Trigger it directly:
   ```bash
   curl -X POST "https://samryan-inventory.<your-subdomain>.workers.dev/api/sticker-now?vin=THE_VIN&title=Jeep%20Wrangler" \
     -H "x-admin-key: YOUR_ADMIN_KEY"
   ```
   (`title` just needs to contain the brand name — Jeep/Ram/Dodge/Chrysler
   — so the code can pick the right manufacturer site.)
3. Check the response:
   - `status: "ok"` with `standard_equipment` / `optional_equipment`
     arrays populated → parser is working, compare the text against the
     actual PDF (the `sticker_url` in the response) for accuracy.
   - `status: "not_found"` → expected for older used vehicles that have
     aged out of the manufacturer's archive; not a bug.
   - `status: "error"` → open the PDF URL yourself in a browser first to
     confirm it's really a PDF and not a blocked/CAPTCHA response, then
     check `last_error` — if it's a CPU-time error, see the Paid plan
     note above; if it's a parse error, the text layout may differ
     enough from what `parseStickerText()` in `src/windowSticker.js`
     expects and the regex there needs adjusting against the real text.
4. Once one VIN looks right, let the scheduled crawl (`runStickerStep`)
   work through the rest automatically — no need to trigger each one by
   hand.

## Adjusting the crawl schedule

`wrangler.toml`'s `[triggers] crons` controls how often this runs.
`*/5 * * * *` (every 5 minutes, 5 pages per tick) clears the roughly
190 total pages across new+used in a few hours — several full
refreshes a day. To go slower/gentler on Covert's server, reduce
`PAGES_PER_RUN` in `src/index.js` or change the cron to `*/15 * * * *`.
