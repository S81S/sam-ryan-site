-- Sam + Ryan inventory database (Cloudflare D1)
-- Run once: wrangler d1 execute samryan-inventory --file=./schema.sql

CREATE TABLE IF NOT EXISTS vehicles (
  stock_number   TEXT PRIMARY KEY,
  vin            TEXT,
  condition      TEXT,           -- 'New' | 'Used'
  year           INTEGER,
  make           TEXT,
  model          TEXT,
  trim           TEXT,
  title          TEXT,           -- full listing title, for display/debugging
  price          INTEGER,
  msrp           INTEGER,
  mileage        INTEGER,
  drivetrain     TEXT,
  engine         TEXT,
  body_style     TEXT,
  exterior_color TEXT,
  status         TEXT,           -- 'in_stock' | 'in_transit' | 'on_order'
  features       TEXT,           -- JSON array, stored as text
  photo_url      TEXT,
  listing_url    TEXT NOT NULL,
  first_seen     TEXT NOT NULL,  -- ISO timestamp, first time we saw this stock number
  last_seen      TEXT NOT NULL,  -- ISO timestamp, most recent crawl that saw it
  removed_at     TEXT,           -- set once a full pass completes without seeing it again
  updated_at     TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_vehicles_condition ON vehicles(condition);
CREATE INDEX IF NOT EXISTS idx_vehicles_removed ON vehicles(removed_at);

CREATE TABLE IF NOT EXISTS price_history (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  stock_number   TEXT NOT NULL,
  price          INTEGER,
  recorded_at    TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_price_history_stock ON price_history(stock_number);

-- Tracks crawl progress so the scheduled worker can process a few pages
-- per run instead of the whole site in one invocation.
CREATE TABLE IF NOT EXISTS crawl_state (
  source            TEXT PRIMARY KEY,   -- 'new' | 'used'
  current_page      INTEGER NOT NULL DEFAULT 1,
  pass_started_at   TEXT,
  last_completed_at TEXT,
  last_error        TEXT
);

INSERT OR IGNORE INTO crawl_state (source, current_page) VALUES ('new', 1);
INSERT OR IGNORE INTO crawl_state (source, current_page) VALUES ('used', 1);

-- One official Monroney label per VIN, fetched directly from the
-- manufacturer (Stellantis hosts these free, by VIN, for Jeep/Ram/Dodge/
-- Chrysler). This is the verified source of truth for equipment — see
-- sources.html's "never invent a feature" rule.
CREATE TABLE IF NOT EXISTS window_stickers (
  vin              TEXT PRIMARY KEY,
  brand            TEXT,             -- jeep | ram | dodge | chrysler
  sticker_url      TEXT,             -- the manufacturer PDF, safe to link/open directly
  status           TEXT,             -- 'ok' | 'not_found' | 'error'
  base_msrp        INTEGER,
  destination      INTEGER,
  total_msrp       INTEGER,
  fuel_economy     TEXT,             -- e.g. "23 city / 31 hwy"
  standard_equipment TEXT,           -- JSON array of strings
  optional_equipment TEXT,           -- JSON array of {name, price}
  fetched_at       TEXT,
  last_error       TEXT
);

-- Cursor so the worker fetches/parses a handful of stickers per run
-- instead of all ~600+ VINs in one invocation (PDF parsing is much
-- heavier per-item than the plain inventory page scrape).
CREATE TABLE IF NOT EXISTS sticker_crawl_state (
  id               INTEGER PRIMARY KEY CHECK (id = 1),
  last_stock_number TEXT
);
INSERT OR IGNORE INTO sticker_crawl_state (id, last_stock_number) VALUES (1, NULL);
