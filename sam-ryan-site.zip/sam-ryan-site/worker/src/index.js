/**
 * Sam + Ryan inventory pipeline
 * ------------------------------------------------------------
 * Two jobs in one Worker:
 *
 * 1. scheduled()  — runs on a cron trigger. Each run crawls a few pages
 *    of Covert's PUBLIC inventory search pages, parses out vehicle
 *    records, and upserts them into D1. When a full pass across every
 *    page finishes, any vehicle not seen in that pass gets marked
 *    removed_at (sold / pulled) and a new pass starts.
 *
 * 2. fetch()      — serves GET /api/inventory as JSON so the static
 *    site's app.js can load real data instead of the hardcoded array.
 *
 * IMPORTANT — calibration required before this is trustworthy:
 * This parser is written against the *rendered content* of Covert's
 * search-results pages (confirmed on Sept 21, 2026), matched with
 * flexible regex rather than exact CSS selectors, because dealer
 * website markup shifts and because a regex on stable label text
 * ("Stock#:", "Vin:", "Covert Sale Price$...") survives small markup
 * changes better than brittle selector chains. Before relying on this:
 *   1. Deploy it, hit POST /api/crawl-now (see README) once.
 *   2. Check GET /api/inventory and compare a few VINs against the
 *      live site.
 *   3. If the count of parsed vehicles per page looks wrong, view page
 *      source on the real site and adjust PAGE_SIZE / regex below —
 *      search notes are in README.md.
 */

import { brandFromTitle, fetchAndParseSticker } from "./windowSticker.js";

const STICKERS_PER_RUN = 5; // PDF fetch+parse is heavier than a page scrape — keep this small

const SOURCES = {
  new: {
    baseUrl: "https://www.covertchryslerdodgejeepram.com/search/new-chrysler-dodge-jeep-ram/?tp=new",
    condition: "New",
  },
  used: {
    baseUrl: "https://www.covertchryslerdodgejeepram.com/search/used/?tp=used",
    condition: "Used",
  },
};

const PAGE_SIZE = 12;        // Covert's default results-per-page
const PAGES_PER_RUN = 5;     // how many pages this worker fetches per cron tick
const USER_AGENT =
  "SamRyanInventoryBot/1.0 (+independent shopping site for Covert CDJR Austin sales consultants; contact via samuelsweitzer@covertauto.com)";

// ---------- entrypoints ----------------------------------------------------

export default {
  async scheduled(event, env, ctx) {
    ctx.waitUntil(runCrawlStep(env, "new"));
    ctx.waitUntil(runCrawlStep(env, "used"));
    ctx.waitUntil(runStickerStep(env));
  },

  async fetch(request, env) {
    const url = new URL(request.url);
    const cors = corsHeaders(env);

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: cors });
    }

    if (url.pathname === "/api/inventory" && request.method === "GET") {
      const condition = url.searchParams.get("condition"); // optional filter
      const rows = await getInventory(env, condition);
      return json(rows, cors);
    }

    if (url.pathname === "/api/inventory/meta" && request.method === "GET") {
      const meta = await getMeta(env);
      return json(meta, cors);
    }

    // Manual trigger for testing/calibration. Protect it with a shared
    // secret so randoms on the internet can't spam your crawler.
    if (url.pathname === "/api/crawl-now" && request.method === "POST") {
      const key = request.headers.get("x-admin-key");
      if (!env.ADMIN_KEY || key !== env.ADMIN_KEY) {
        return json({ error: "unauthorized" }, cors, 401);
      }
      const source = url.searchParams.get("source") === "used" ? "used" : "new";
      const result = await runCrawlStep(env, source);
      return json(result, cors);
    }

    // Manual test for ONE specific VIN — the fastest way to calibrate the
    // sticker parser after first deploy (see README).
    if (url.pathname === "/api/sticker-now" && request.method === "POST") {
      const key = request.headers.get("x-admin-key");
      if (!env.ADMIN_KEY || key !== env.ADMIN_KEY) {
        return json({ error: "unauthorized" }, cors, 401);
      }
      const vin = url.searchParams.get("vin");
      const brand = url.searchParams.get("brand"); // optional override
      if (!vin) return json({ error: "missing ?vin=" }, cors, 400);
      const result = await fetchAndParseSticker(vin, brand || brandFromTitle(url.searchParams.get("title") || ""));
      await saveStickerResult(env, vin, brand, result);
      return json(result, cors);
    }

    // Manual trigger for the batched sticker crawl step.
    if (url.pathname === "/api/sticker-crawl-now" && request.method === "POST") {
      const key = request.headers.get("x-admin-key");
      if (!env.ADMIN_KEY || key !== env.ADMIN_KEY) {
        return json({ error: "unauthorized" }, cors, 401);
      }
      const result = await runStickerStep(env);
      return json(result, cors);
    }

    if (url.pathname === "/api/window-sticker" && request.method === "GET") {
      const vin = url.searchParams.get("vin");
      if (!vin) return json({ error: "missing ?vin=" }, cors, 400);
      const row = await env.DB.prepare("SELECT * FROM window_stickers WHERE vin = ?").bind(vin).first();
      return json(row || { status: "unknown" }, cors);
    }

    return json({ error: "not found" }, cors, 404);
  },
};

// ---------- crawl logic -----------------------------------------------------

async function runCrawlStep(env, sourceKey) {
  const source = SOURCES[sourceKey];
  const state = await getCrawlState(env, sourceKey);
  const now = new Date().toISOString();
  const passStart = state.pass_started_at || now;

  let page = state.current_page || 1;
  let pagesProcessed = 0;
  let totalPages = null;
  let vehiclesSeen = 0;

  try {
    for (; pagesProcessed < PAGES_PER_RUN; pagesProcessed++) {
      const pageUrl = pageUrlFor(source.baseUrl, page);
      const res = await fetch(pageUrl, {
        headers: { "User-Agent": USER_AGENT },
      });
      if (!res.ok) throw new Error(`Fetch failed (${res.status}) for ${pageUrl}`);
      const html = await res.text();

      if (totalPages === null) totalPages = parseTotalPages(html) ?? totalPages;
      const vehicles = parseVehicles(html, source.condition);
      vehiclesSeen += vehicles.length;

      for (const v of vehicles) {
        await upsertVehicle(env, v, now, passStart);
      }

      // Stop early if this page had nothing — we've run off the end.
      if (vehicles.length === 0) {
        page = 1;
        await finishPass(env, sourceKey, passStart, now);
        await setCrawlState(env, sourceKey, { current_page: 1, pass_started_at: null });
        return { source: sourceKey, pagesProcessed: pagesProcessed + 1, vehiclesSeen, passComplete: true };
      }

      page += 1;
      if (totalPages && page > totalPages) {
        await finishPass(env, sourceKey, passStart, now);
        await setCrawlState(env, sourceKey, { current_page: 1, pass_started_at: null });
        return { source: sourceKey, pagesProcessed: pagesProcessed + 1, vehiclesSeen, passComplete: true, totalPages };
      }
    }

    // Ran out of PAGES_PER_RUN for this tick without finishing the pass —
    // save the cursor so the next cron tick picks up where we left off.
    await setCrawlState(env, sourceKey, { current_page: page, pass_started_at: passStart, last_error: null });
    return { source: sourceKey, pagesProcessed, vehiclesSeen, passComplete: false, nextPage: page };
  } catch (err) {
    await setCrawlState(env, sourceKey, { last_error: String(err) });
    return { source: sourceKey, error: String(err) };
  }
}

function pageUrlFor(baseUrl, page) {
  // TODO — CALIBRATE: confirm the real pagination query param by viewing
  // page 2 of the live search results in a browser and copying its URL.
  // Common Dealer eProcess patterns are `?pt=2` or `&pn=2`; this defaults
  // to `pt`. Update here if the live site uses something different.
  const url = new URL(baseUrl);
  if (page > 1) url.searchParams.set("pt", String(page));
  return url.toString();
}

function parseTotalPages(html) {
  // Looks for the "Page X of Y" pager text.
  const m = html.match(/Page\s*<[^>]*>?\s*(\d+)\s*<\/[^>]*>?\s*of\s*<[^>]*>?\s*(\d+)/i)
    || html.match(/Page\s+\d+\s+of\s+(\d+)/i);
  if (!m) return null;
  const n = Number(m[m.length - 1]);
  return Number.isFinite(n) ? n : null;
}

/**
 * Parses one search-results page into an array of vehicle records.
 * Deliberately regex/text-marker based (see file header) rather than
 * DOM-selector based, so it degrades gracefully across small markup
 * changes. Each vehicle "card" is located by its Stock#/Vin line, then
 * nearby text is scanned for title, price, mileage and listing URL.
 */
function parseVehicles(html, condition) {
  const vehicles = [];
  const cardRe = /Stock#:\s*([A-Za-z0-9]+)\s*\|\s*Vin:\s*([A-HJ-NPR-Z0-9]{17})/gi;
  let match;

  while ((match = cardRe.exec(html)) !== null) {
    const stock = match[1].trim();
    const vin = match[2].trim();
    const idx = match.index;

    // Look ~4000 chars before and ~4000 after the Stock/Vin marker for
    // the rest of this listing's details — cards run long because they
    // include full description text.
    const windowStart = Math.max(0, idx - 4000);
    const windowEnd = Math.min(html.length, idx + 4000);
    const block = html.slice(windowStart, windowEnd);

    const listingUrl = firstMatch(block, /https:\/\/www\.covertchryslerdodgejeepram\.com\/auto\/[a-z0-9-]+\/\d+\//i);
    const title = firstMatch(block, /(NEW|USED)\s+\d{4}\s+[A-Z0-9 ./-]+?(?=<)/i) || firstMatch(html.slice(Math.max(0, idx - 400), idx), />([^<]{10,90})<\/a>\s*$/i);
    const price = firstNumber(block, /Covert Sale Price\$?([\d,]+)/i) ?? firstNumber(block, /Sale Price\$?([\d,]+)/i);
    const msrp = firstNumber(block, /MSRP\D{0,10}\$?([\d,]+)/i);
    const mileageMatch = block.match(/In Stock(\d+)/i); // Covert shows days-in-stock, not mileage, next to "In Stock" — mileage below covers used listings' odometer text if present
    const mileage = firstNumber(block, /([\d,]+)\s*miles/i);
    const engine = firstMatch(block, /\d\.\dL\s*[A-Za-z0-9 ]+?(?=[.,]|Engine)/i);
    const drivetrain = firstMatch(block, /\b(4WD|AWD|RWD|FWD|4x4|4x2)\b/i);
    const yearMatch = title && title.match(/\b(19|20)\d{2}\b/);
    const year = yearMatch ? Number(yearMatch[0]) : null;

    const makeModel = title
      ? title.replace(/^(NEW|USED)\s+\d{4}\s+/i, "").trim()
      : null;

    if (!stock || !vin || !listingUrl) continue; // incomplete parse — skip rather than store garbage

    vehicles.push({
      stock_number: stock,
      vin,
      condition,
      year,
      title: makeModel,
      price: price ?? null,
      msrp: msrp ?? null,
      mileage: mileage ?? null,
      drivetrain: drivetrain ? drivetrain.toUpperCase() : null,
      engine: engine ? engine.trim() : null,
      listing_url: listingUrl,
    });
  }

  return vehicles;
}

function firstMatch(text, re) {
  const m = text.match(re);
  return m ? (m[1] ?? m[0]).trim() : null;
}
function firstNumber(text, re) {
  const m = text.match(re);
  if (!m) return null;
  const n = Number(m[1].replace(/,/g, ""));
  return Number.isFinite(n) ? n : null;
}

// ---------- window sticker crawl step -----------------------------------

async function runStickerStep(env) {
  const state = await env.DB.prepare("SELECT last_stock_number FROM sticker_crawl_state WHERE id = 1").first();
  const after = state?.last_stock_number || "";

  // Pick the next batch of vehicles that either have no sticker row yet
  // or whose sticker fetch previously errored (worth retrying); skip
  // ones already marked 'ok' or 'not_found' — those don't change.
  const { results: batch } = await env.DB.prepare(
    `SELECT v.stock_number, v.vin, v.title FROM vehicles v
     LEFT JOIN window_stickers w ON w.vin = v.vin
     WHERE v.removed_at IS NULL
       AND v.stock_number > ?
       AND (w.vin IS NULL OR w.status = 'error')
     ORDER BY v.stock_number ASC
     LIMIT ?`
  )
    .bind(after, STICKERS_PER_RUN)
    .all();

  if (batch.length === 0) {
    // Reached the end — reset cursor so we loop back and pick up any
    // newly-added vehicles from scratch next time.
    await env.DB.prepare(
      "INSERT INTO sticker_crawl_state (id, last_stock_number) VALUES (1, NULL) ON CONFLICT(id) DO UPDATE SET last_stock_number = NULL"
    ).run();
    return { processed: 0, wrapped: true };
  }

  let processed = 0;
  for (const vehicle of batch) {
    const brand = brandFromTitle(vehicle.title);
    if (vehicle.vin && brand) {
      const result = await fetchAndParseSticker(vehicle.vin, brand);
      await saveStickerResult(env, vehicle.vin, brand, result);
    } else {
      await saveStickerResult(env, vehicle.vin, brand, { status: "error", last_error: "no VIN or unrecognized brand" });
    }
    processed++;
  }

  const last = batch[batch.length - 1].stock_number;
  await env.DB.prepare(
    "INSERT INTO sticker_crawl_state (id, last_stock_number) VALUES (1, ?) ON CONFLICT(id) DO UPDATE SET last_stock_number = ?"
  )
    .bind(last, last)
    .run();

  return { processed, lastStockNumber: last };
}

async function saveStickerResult(env, vin, brand, result) {
  if (!vin) return;
  const now = new Date().toISOString();
  await env.DB.prepare(
    `INSERT INTO window_stickers
       (vin, brand, sticker_url, status, base_msrp, destination, total_msrp,
        fuel_economy, standard_equipment, optional_equipment, fetched_at, last_error)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(vin) DO UPDATE SET
       brand = excluded.brand,
       sticker_url = excluded.sticker_url,
       status = excluded.status,
       base_msrp = excluded.base_msrp,
       destination = excluded.destination,
       total_msrp = excluded.total_msrp,
       fuel_economy = excluded.fuel_economy,
       standard_equipment = excluded.standard_equipment,
       optional_equipment = excluded.optional_equipment,
       fetched_at = excluded.fetched_at,
       last_error = excluded.last_error`
  )
    .bind(
      vin,
      brand || null,
      result.sticker_url || null,
      result.status || "error",
      result.base_msrp ?? null,
      result.destination ?? null,
      result.total_msrp ?? null,
      result.fuel_economy ?? null,
      result.standard_equipment ?? null,
      result.optional_equipment ?? null,
      now,
      result.last_error ?? null
    )
    .run();
}

// ---------- D1 access --------------------------------------------------

async function getCrawlState(env, source) {
  const row = await env.DB.prepare("SELECT * FROM crawl_state WHERE source = ?").bind(source).first();
  return row || { source, current_page: 1 };
}

async function setCrawlState(env, source, patch) {
  const existing = await getCrawlState(env, source);
  const merged = { ...existing, ...patch };
  await env.DB.prepare(
    `INSERT INTO crawl_state (source, current_page, pass_started_at, last_completed_at, last_error)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(source) DO UPDATE SET
       current_page = excluded.current_page,
       pass_started_at = excluded.pass_started_at,
       last_completed_at = excluded.last_completed_at,
       last_error = excluded.last_error`
  )
    .bind(
      source,
      merged.current_page ?? 1,
      merged.pass_started_at ?? null,
      merged.last_completed_at ?? null,
      merged.last_error ?? null
    )
    .run();
}

async function finishPass(env, source, passStart, finishedAt) {
  // Anything of this condition not seen since the pass began is gone
  // (sold / removed) — mark it rather than deleting, so history survives.
  const condition = SOURCES[source].condition;
  await env.DB.prepare(
    `UPDATE vehicles SET removed_at = ?
     WHERE condition = ? AND (last_seen < ?) AND removed_at IS NULL`
  )
    .bind(finishedAt, condition, passStart)
    .run();

  await env.DB.prepare(
    `UPDATE crawl_state SET last_completed_at = ? WHERE source = ?`
  )
    .bind(finishedAt, source)
    .run();
}

async function upsertVehicle(env, v, seenAt, passStart) {
  const existing = await env.DB
    .prepare("SELECT price FROM vehicles WHERE stock_number = ?")
    .bind(v.stock_number)
    .first();

  await env.DB.prepare(
    `INSERT INTO vehicles
       (stock_number, vin, condition, year, make, model, trim, title, price, msrp,
        mileage, drivetrain, engine, body_style, exterior_color, status, features,
        photo_url, listing_url, first_seen, last_seen, removed_at, updated_at)
     VALUES (?, ?, ?, ?, NULL, NULL, NULL, ?, ?, ?, ?, ?, ?, NULL, NULL, NULL, NULL, NULL, ?, ?, ?, NULL, ?)
     ON CONFLICT(stock_number) DO UPDATE SET
       vin = excluded.vin,
       condition = excluded.condition,
       year = excluded.year,
       title = excluded.title,
       price = excluded.price,
       msrp = excluded.msrp,
       mileage = excluded.mileage,
       drivetrain = excluded.drivetrain,
       engine = excluded.engine,
       listing_url = excluded.listing_url,
       last_seen = excluded.last_seen,
       removed_at = NULL,
       updated_at = excluded.updated_at`
  )
    .bind(
      v.stock_number,
      v.vin,
      v.condition,
      v.year,
      v.title,
      v.price,
      v.msrp,
      v.mileage,
      v.drivetrain,
      v.engine,
      v.listing_url,
      seenAt,
      seenAt,
      seenAt
    )
    .run();

  if (!existing || existing.price !== v.price) {
    await env.DB.prepare(
      "INSERT INTO price_history (stock_number, price, recorded_at) VALUES (?, ?, ?)"
    )
      .bind(v.stock_number, v.price, seenAt)
      .run();
  }
}

async function getInventory(env, condition) {
  const base = `
    SELECT v.*,
           w.sticker_url, w.status AS sticker_status, w.fuel_economy,
           w.base_msrp AS sticker_base_msrp, w.total_msrp AS sticker_total_msrp,
           w.standard_equipment, w.optional_equipment
    FROM vehicles v
    LEFT JOIN window_stickers w ON w.vin = v.vin
    WHERE v.removed_at IS NULL`;
  const query = condition ? `${base} AND v.condition = ? ORDER BY v.updated_at DESC` : `${base} ORDER BY v.updated_at DESC`;
  const stmt = condition ? env.DB.prepare(query).bind(condition) : env.DB.prepare(query);
  const { results } = await stmt.all();
  return results.map((row) => ({
    ...row,
    standard_equipment: safeParseJson(row.standard_equipment) || [],
    optional_equipment: safeParseJson(row.optional_equipment) || [],
  }));
}

function safeParseJson(text) {
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

async function getMeta(env) {
  const newState = await getCrawlState(env, "new");
  const usedState = await getCrawlState(env, "used");
  const counts = await env.DB
    .prepare("SELECT condition, COUNT(*) as n FROM vehicles WHERE removed_at IS NULL GROUP BY condition")
    .all();
  const stickerCounts = await env.DB
    .prepare("SELECT status, COUNT(*) as n FROM window_stickers GROUP BY status")
    .all();
  return { new: newState, used: usedState, counts: counts.results, stickers: stickerCounts.results };
}

// ---------- helpers ------------------------------------------------------

function json(data, extraHeaders = {}, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...extraHeaders },
  });
}

function corsHeaders(env) {
  return {
    "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN || "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, x-admin-key",
  };
}
