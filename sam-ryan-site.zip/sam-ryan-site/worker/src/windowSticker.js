/**
 * Official window sticker (Monroney label) retrieval + parsing.
 *
 * Stellantis publishes these directly, by VIN, for free — no login, no
 * third-party lookup service needed:
 *   https://www.jeep.com/hostd/windowsticker/getWindowStickerPdf.do?vin=<VIN>
 *   https://www.ramtrucks.com/hostd/windowsticker/getWindowStickerPdf.do?vin=<VIN>
 *   https://www.dodge.com/hostd/windowsticker/getWindowStickerPdf.do?vin=<VIN>
 *   https://www.chrysler.com/hostd/windowsticker/getWindowStickerPdf.do?vin=<VIN>
 *
 * CALIBRATION NOTE: this pattern is confirmed by multiple independent
 * sources (see worker/README.md) but was not hand-tested against a live
 * VIN before deploy, since I can't reach the open internet from where
 * this was built. First deploy should hit POST /api/sticker-now?vin=...
 * for one known VIN and confirm a real PDF comes back before trusting
 * this broadly. Likely failure modes: older/used VINs aging out of the
 * manufacturer's archive (expected — that's what status:'not_found' is
 * for, not a bug), or the brand→hostname guess below being wrong for an
 * edge-case model name.
 */

import { extractText, getDocumentProxy } from "unpdf";

const BRAND_HOSTS = {
  jeep: "www.jeep.com",
  ram: "www.ramtrucks.com",
  dodge: "www.dodge.com",
  chrysler: "www.chrysler.com",
};

export function brandFromTitle(title) {
  const t = (title || "").toLowerCase();
  if (t.includes("ram")) return "ram";
  if (t.includes("jeep")) return "jeep";
  if (t.includes("dodge")) return "dodge";
  if (t.includes("chrysler")) return "chrysler";
  return null;
}

export function windowStickerUrl(brand, vin) {
  const host = BRAND_HOSTS[brand];
  if (!host) return null;
  return `https://${host}/hostd/windowsticker/getWindowStickerPdf.do?vin=${encodeURIComponent(vin)}`;
}

export async function fetchAndParseSticker(vin, brand) {
  const url = windowStickerUrl(brand, vin);
  if (!url) return { status: "error", last_error: `no known site for brand ${brand}` };

  const res = await fetch(url, {
    headers: {
      "User-Agent": "Mozilla/5.0 (compatible; SamRyanInventoryBot/1.0)",
      Accept: "application/pdf",
    },
  });

  if (res.status === 404) return { status: "not_found", sticker_url: url };
  if (!res.ok) return { status: "error", sticker_url: url, last_error: `HTTP ${res.status}` };

  const contentType = res.headers.get("content-type") || "";
  const bytes = new Uint8Array(await res.arrayBuffer());

  // Some brand sites return a 200 with an HTML "not found" page instead
  // of a real 404 — guard against that before handing it to the PDF parser.
  if (!contentType.includes("pdf") && looksLikeHtml(bytes)) {
    return { status: "not_found", sticker_url: url };
  }

  try {
    const pdf = await getDocumentProxy(bytes);
    const { text } = await extractText(pdf, { mergePages: true });
    return { status: "ok", sticker_url: url, ...parseStickerText(text) };
  } catch (err) {
    return { status: "error", sticker_url: url, last_error: `PDF parse failed: ${err}` };
  }
}

function looksLikeHtml(bytes) {
  const head = new TextDecoder().decode(bytes.slice(0, 200)).toLowerCase();
  return head.includes("<html") || head.includes("<!doctype");
}

/**
 * Turns raw extracted PDF text into structured fields. Monroney labels
 * are fairly consistent across Stellantis brands but not identical —
 * this looks for stable label text ("Total Vehicle Price", "MSRP",
 * "STANDARD EQUIPMENT", fuel-economy "XX City / YY Hwy" pattern) rather
 * than fixed line positions, for the same resilience reasons as the
 * inventory-page parser. Expect to refine this after seeing a few real
 * examples — see README calibration steps.
 */
function parseStickerText(text) {
  const flat = text.replace(/\s+/g, " ");

  const baseMsrp = firstNumber(flat, /Base\s*(?:Vehicle)?\s*Price\D{0,10}\$?([\d,]+)/i);
  const destination = firstNumber(flat, /Destination\s*(?:Charge|Freight)\D{0,10}\$?([\d,]+)/i);
  const totalMsrp = firstNumber(flat, /Total\s*(?:Vehicle\s*)?Price\D{0,15}\$?([\d,]+)/i)
    ?? firstNumber(flat, /\bMSRP\b\D{0,10}\$?([\d,]+)/i);

  const fuelEconomy = firstMatch(flat, /(\d{1,3})\s*City\s*\/\s*(\d{1,3})\s*Hwy/i);
  const fuelEconomyText = fuelEconomy ? fuelEconomy.replace(/\s+/g, " ") : null;

  const standardEquipment = extractListSection(flat, /STANDARD EQUIPMENT/i, /OPTIONAL EQUIPMENT|MECHANICAL|SAFETY|FUEL ECONOMY/i);
  const optionalRaw = extractListSection(flat, /OPTIONAL EQUIPMENT/i, /FUEL ECONOMY|TOTAL (VEHICLE )?PRICE|WARRANTY/i);
  const optionalEquipment = optionalRaw
    .map((line) => {
      const m = line.match(/^(.*?)\s*\$?([\d,]{2,})\s*$/);
      return m ? { name: m[1].trim(), price: Number(m[2].replace(/,/g, "")) } : { name: line.trim(), price: null };
    })
    .filter((o) => o.name && o.name.length > 1);

  return {
    base_msrp: baseMsrp,
    destination,
    total_msrp: totalMsrp,
    fuel_economy: fuelEconomyText,
    standard_equipment: JSON.stringify(standardEquipment.slice(0, 60)),
    optional_equipment: JSON.stringify(optionalEquipment.slice(0, 40)),
  };
}

function extractListSection(flat, startRe, endRe) {
  const startMatch = flat.match(startRe);
  if (!startMatch) return [];
  const start = startMatch.index + startMatch[0].length;
  const rest = flat.slice(start);
  const endMatch = rest.match(endRe);
  const section = endMatch ? rest.slice(0, endMatch.index) : rest.slice(0, 3000);

  // Monroney text tends to separate items with multiple spaces or bullet
  // characters rather than real line breaks once PDF text is flattened.
  return section
    .split(/\s{2,}|•|\n/)
    .map((s) => s.trim())
    .filter((s) => s.length > 2 && s.length < 120 && !/^\d+$/.test(s));
}

function firstMatch(text, re) {
  const m = text.match(re);
  return m ? m[0] : null;
}
function firstNumber(text, re) {
  const m = text.match(re);
  if (!m) return null;
  const n = Number(m[1].replace(/,/g, ""));
  return Number.isFinite(n) ? n : null;
}
